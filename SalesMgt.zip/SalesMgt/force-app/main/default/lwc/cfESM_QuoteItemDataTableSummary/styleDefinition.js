let styleDefinition =
      {"state0element0block_element2block_element0":[{"conditions":"default","styleObject":{"class":"slds-col  condition-element  slds-size_12-of-12  ","style":"      \n         ","styleProperties":{}}}]};
  export default styleDefinition