let styleDefinition =
      {"state0element1":[{"conditions":"default","styleObject":{"class":"slds-col  condition-element b2b-selfservice-spinner slds-size_12-of-12  ","style":"      \n         ","styleProperties":{}}}]};
  export default styleDefinition