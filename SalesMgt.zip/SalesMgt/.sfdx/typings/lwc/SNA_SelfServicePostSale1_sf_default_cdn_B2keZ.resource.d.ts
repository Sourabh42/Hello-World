declare module "@salesforce/resourceUrl/SNA_SelfServicePostSale1_sf_default_cdn_B2keZ" {
    var SNA_SelfServicePostSale1_sf_default_cdn_B2keZ: string;
    export default SNA_SelfServicePostSale1_sf_default_cdn_B2keZ;
}