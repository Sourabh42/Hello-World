declare module "@salesforce/resourceUrl/SelfService_LogOut_Button" {
    var SelfService_LogOut_Button: string;
    export default SelfService_LogOut_Button;
}