declare module "@salesforce/resourceUrl/SelfService_CompanyLogo" {
    var SelfService_CompanyLogo: string;
    export default SelfService_CompanyLogo;
}