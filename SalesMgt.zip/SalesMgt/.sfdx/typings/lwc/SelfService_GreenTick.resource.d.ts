declare module "@salesforce/resourceUrl/SelfService_GreenTick" {
    var SelfService_GreenTick: string;
    export default SelfService_GreenTick;
}