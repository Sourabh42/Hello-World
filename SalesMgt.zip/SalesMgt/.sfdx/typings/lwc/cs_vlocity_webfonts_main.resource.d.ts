declare module "@salesforce/resourceUrl/cs_vlocity_webfonts_main" {
    var cs_vlocity_webfonts_main: string;
    export default cs_vlocity_webfonts_main;
}